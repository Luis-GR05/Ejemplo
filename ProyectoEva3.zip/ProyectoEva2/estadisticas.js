document.addEventListener('DOMContentLoaded', function() {
    // Cargar partidas desde localStorage
    function cargarPartidas() {
        try {
            const partidasStorage = localStorage.getItem('partidas');
            if (partidasStorage) {
                return JSON.parse(partidasStorage);
            }
        } catch (e) {
            console.error('Error al cargar partidas:', e);
        }
        return [];
    }
    
    let partidas = cargarPartidas();
    
    // Elementos del DOM
    const cuerpoTabla = document.getElementById('cuerpo-tabla');
    const totalPartidas = document.getElementById('total-partidas');
    const victoriasP1 = document.getElementById('victorias-p1');
    const victoriasP2 = document.getElementById('victorias-p2');
    const empates = document.getElementById('empates');
    const filtroJugador = document.getElementById('filtro-jugador');
    const filtroResultado = document.getElementById('filtro-resultado');
    const btnRefrescar = document.getElementById('btn-refrescar');
    
    // Ocultar el filtro de resultados (pero mantenerlo funcional)
    filtroResultado.style.display = 'none';
    
    // Cargar estadísticas
    function cargarEstadisticas() {
        const partidasFiltradas = filtrarPartidas();
        
        // Actualizar resumen
        totalPartidas.textContent = partidasFiltradas.length;
        
        const victoriasJ1 = partidasFiltradas.filter(p => 
            p.jugador1.resultado === 'victoria').length;
        const victoriasJ2 = partidasFiltradas.filter(p => 
            p.jugador2.resultado === 'victoria').length;
        const totalEmpates = partidasFiltradas.filter(p => 
            p.jugador1.resultado === 'empate').length;
        
        victoriasP1.textContent = victoriasJ1;
        victoriasP2.textContent = victoriasJ2;
        empates.textContent = totalEmpates;
        
        // Actualizar tabla
        cuerpoTabla.innerHTML = '';
        
        if (partidasFiltradas.length === 0) {
            const fila = document.createElement('tr');
            fila.innerHTML = `<td colspan="6" style="text-align: center;">No hay partidas registradas</td>`;
            cuerpoTabla.appendChild(fila);
            return;
        }
        
        partidasFiltradas.forEach(partida => {
            const fila = document.createElement('tr');
            
            // Formatear fecha
            const fecha = new Date(partida.fecha);
            const fechaFormateada = fecha.toLocaleDateString() + ' ' + fecha.toLocaleTimeString();
            
            // Formatear duración de manera segura
            let duracionFormateada = "N/A";
            if (partida.duracion && !isNaN(partida.duracion) && partida.duracion > 0) {
                const segundos = Math.round(partida.duracion / 1000);
                if (segundos < 60) {
                    duracionFormateada = `${segundos} seg`;
                } else {
                    const minutos = Math.floor(segundos / 60);
                    const segundosRestantes = segundos % 60;
                    duracionFormateada = `${minutos} min ${segundosRestantes} seg`;
                }
            }
            // Determinar resultado
            let resultado = '';
            let claseResultado = '';
            if (partida.jugador1.resultado === 'empate') {
                resultado = 'Empate';
                claseResultado = 'empate';
            } else if (partida.jugador1.resultado === 'victoria') {
                resultado = `Gana ${partida.jugador1.nombre}`;
                claseResultado = 'victoria';
            } else {
                resultado = `Gana ${partida.jugador2.nombre}`;
                claseResultado = 'derrota';
            }
            
            fila.innerHTML = `
                <td>${fechaFormateada}</td>
                <td>${partida.jugador1.nombre} (${partida.jugador1.tipo})</td>
                <td>${partida.jugador2.nombre} (${partida.jugador2.tipo})</td>
                <td>${duracionFormateada}</td>
                <td class="${claseResultado}">${resultado}</td>
                <td><button class="boton btn-detalles" data-id="${partida.id}">Detalles</button></td>
            `;
            
            cuerpoTabla.appendChild(fila);
        });
        
        // Añadir event listeners a los botones de detalles
        document.querySelectorAll('.btn-detalles').forEach(btn => {
            btn.addEventListener('click', function() {
                const idPartida = this.getAttribute('data-id');
                mostrarDetallesPartida(idPartida);
            });
        });
    }
    
    // Filtrar partidas - ahora solo por tipo de personaje
    function filtrarPartidas() {
        const tipoJugador = filtroJugador.value;
        return tipoJugador === 'todos' 
            ? partidas 
            : partidas.filter(p => 
                p.jugador1.tipo === tipoJugador || 
                p.jugador2.tipo === tipoJugador);
    }
    
    // Mostrar detalles de una partida específica
    function mostrarDetallesPartida(id) {
        const partida = partidas.find(p => p.id === id);
        if (!partida) return;
        
        // Formatear duración solo en segundos
        let duracionFormateada;
        if (partida.duracion && partida.duracion > 0) {
            const segundos = Math.round(partida.duracion / 1000);
            if (segundos < 60) {
            duracionFormateada = `${segundos} segundos`;
            } else {
            const minutos = Math.floor(segundos / 60);
            const segundosRestantes = segundos % 60;
            duracionFormateada = `${minutos} minuto${minutos !== 1 ? 's' : ''} ${segundosRestantes} segundo${segundosRestantes !== 1 ? 's' : ''}`;
            }
        } else {
            duracionFormateada = "Duración no registrada";
        }
        
        const modal = document.createElement('div');
        modal.className = 'modal-detalles';
        modal.innerHTML = `
            <div class="modal-contenido">
                <h3>Partida del ${new Date(partida.fecha).toLocaleString()}</h3>
                <p><strong>Duración:</strong> ${duracionFormateada}</p>
                
                <div class="detalles-jugadores">
                    <div class="jugador-detalle">
                        <h4>${partida.jugador1.nombre} (${partida.jugador1.tipo})</h4>
                        <p><strong>Resultado:</strong> ${partida.jugador1.resultado === 'victoria' ? 'Victoria' : partida.jugador1.resultado === 'empate' ? 'Empate' : 'Derrota'}</p>
                        <p><strong>Daño total:</strong> ${partida.jugador1.dañoTotal || 0}</p>
                        <p><strong>Daño recibido:</strong> ${partida.jugador1.dañoRecibido || 0}</p>
                        <p><strong>Especiales usados:</strong> ${partida.jugador1.especialesUsados || 0}</p>
                        <p><strong>Esquivadas:</strong> ${partida.jugador1.esquivadas || 0}</p>
                    </div>
                    
                    <div class="jugador-detalle">
                        <h4>${partida.jugador2.nombre} (${partida.jugador2.tipo})</h4>
                        <p><strong>Resultado:</strong> ${partida.jugador2.resultado === 'victoria' ? 'Victoria' : partida.jugador2.resultado === 'empate' ? 'Empate' : 'Derrota'}</p>
                        <p><strong>Daño total:</strong> ${partida.jugador2.dañoTotal || 0}</p>
                        <p><strong>Daño recibido:</strong> ${partida.jugador2.dañoRecibido || 0}</p>
                        <p><strong>Especiales usados:</strong> ${partida.jugador2.especialesUsados || 0}</p>
                        <p><strong>Esquivadas:</strong> ${partida.jugador2.esquivadas || 0}</p>
                    </div>
                </div>
                
                <button id="btn-cerrar-detalles" class="boton">Cerrar</button>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        document.getElementById('btn-cerrar-detalles').addEventListener('click', function() {
            document.body.removeChild(modal);
        });
    }
    
    // Event listeners
    filtroJugador.addEventListener('change', cargarEstadisticas);
    btnRefrescar.addEventListener('click', function() {
        partidas = cargarPartidas();
        cargarEstadisticas();
    });
    
    // Cargar datos iniciales
    cargarEstadisticas();
});