function guardarPartida(ganador, duracion) {
  // Solo guardar si la partida no fue abandonada
  if (partidaAbandonada) return;
    
  let duracionMs = Math.max(1000, Math.min(duracion, 180000));
  // Generar ID único para la partida
  const idPartida = Date.now().toString();
  
  const partidaData = {
      id: idPartida,
      fecha: new Date().toISOString(),
      duracion: duracionMs,
      jugador1: {
          tipo: players.player1.type,
          nombre: players.player1.name,
          dañoTotal: players.player1.damageDealt || 0,
          dañoRecibido: (CONFIG.MAX_HEALTH - players.player1.health),
          especialesUsados: players.player1.specialsUsed || 0,
          esquivadas: players.player1.dodgesUsed || 0,
          resultado: ganador === 'player1' ? 'victoria' : 
                    ganador === null ? 'empate' : 'derrota'
      },
      jugador2: {
          tipo: players.player2.type,
          nombre: players.player2.name,
          dañoTotal: players.player2.damageDealt || 0,
          dañoRecibido: (CONFIG.MAX_HEALTH - players.player2.health),
          especialesUsados: players.player2.specialsUsed || 0,
          esquivadas: players.player2.dodgesUsed || 0,
          resultado: ganador === 'player2' ? 'victoria' : 
                    ganador === null ? 'empate' : 'derrota'
      }
  };

  // Obtener partidas existentes o inicializar array
  let partidasGuardadas = [];
  const partidasStorage = localStorage.getItem('partidas');
  if (partidasStorage) {
      partidasGuardadas = JSON.parse(partidasStorage);
      
      // Limitar el historial a las últimas 50 partidas para no consumir mucho espacio
      if (partidasGuardadas.length >= 50) {
          partidasGuardadas = partidasGuardadas.slice(-49);
      }
  }
  
  // Agregar nueva partida
  partidasGuardadas.push(partidaData);
  
  // Guardar en localStorage
  try {
      localStorage.setItem('partidas', JSON.stringify(partidasGuardadas));
      console.log('Partida guardada correctamente');
  } catch (e) {
      console.error('Error al guardar la partida:', e);
      // Intentar con menos datos si falla por tamaño
      const partidaLight = {
          id: partidaData.id,
          fecha: partidaData.fecha,
          duracion: partidaData.duracion,
          jugador1: {
              tipo: partidaData.jugador1.tipo,
              resultado: partidaData.jugador1.resultado
          },
          jugador2: {
              tipo: partidaData.jugador2.tipo,
              resultado: partidaData.jugador2.resultado
          }
      };
      localStorage.setItem('partidas', JSON.stringify([...partidasGuardadas.slice(0, -1), partidaLight]));
  }
  
  // Resetear contadores
  resetearContadores();
}

function resetearContadores() {
  players.player1.damageDealt = 0;
  players.player2.damageDealt = 0;
  players.player1.specialsUsed = 0;
  players.player2.specialsUsed = 0;
  players.player1.dodgesUsed = 0;
  players.player2.dodgesUsed = 0;
  partidaAbandonada = false;
}

if (!window.MutationObserver) {
  console.warn("MutationObserver no soportado en este navegador");
}

// Configuración global del juego
const CONFIG = {
  MAX_HEALTH: 100,
  MAX_ENERGY: 100,
  ATTACK_COOLDOWN: 3000,   // 3 segundos
  SPECIAL_COOLDOWN: 3000,  // 3 segundos
  DODGE_COOLDOWN: 3000,    // 3 segundos
  ENERGY_REGEN_RATE: 0.005, // Por milisegundo
  
};

// Variables globales y caché de elementos
let timerDisplay;
let actionsDisplay;
let countdownDisplay;
let gameStartTimestamp = 0;
// Variables globales para controlar el estado del juego
let partidaEnCurso = false;
let partidaAbandonada = false;

document.addEventListener("DOMContentLoaded", () => {
  timerDisplay = document.getElementById("timer");
  actionsDisplay = document.getElementById("actions");
  countdownDisplay = document.getElementById("countdown"); // Opcional, para el countdown

  if (!timerDisplay || !actionsDisplay) {
    console.error("Elementos del DOM no encontrados!");
    return;
  }

  document.addEventListener("keydown", handleInput);
  document.addEventListener("keyup", handleInput);

  // Inicia el juego
  initGame();
});

// Datos de los jugadores
const players = {
  player1: {
    name: "Jugador 1",
    health: CONFIG.MAX_HEALTH,
    energy: CONFIG.MAX_ENERGY,
    type: null,
    cooldown: 0,
    specialCooldown: 0,
    isInvisible: false,
    canAttack: true,
    dodgeCooldown: 0,
    attackDamage: 0,
    specialDamage: 0,
    energyCost: 0,
    normalEnergyCost: 0,
  },
  player2: {
    name: "Jugador 2",
    health: CONFIG.MAX_HEALTH,
    energy: CONFIG.MAX_ENERGY,
    type: null,
    cooldown: 0,
    specialCooldown: 0,
    isInvisible: false,
    canAttack: true,
    dodgeCooldown: 0,
    attackDamage: 0,
    specialDamage: 0,
    energyCost: 0,
    normalEnergyCost: 0,
  },
};

const keys = {
  KeyA: false,
  KeyS: false,
  KeyD: false,
  KeyK: false,
  KeyL: false,
  KeyJ: false,
  Space: false,
};

// Parámetros del juego
const game = {
  isRunning: false,
  startTime: null,
  lastFrame: null,
};

// Cacheo de elementos HUD para optimizar actualizaciones
const HUD = {
  player1: {
    health: document.getElementById("health1"),
    energy: document.getElementById("energy1"),
    healthPercent: document.getElementById("health1-percent"),
    energyPercent: document.getElementById("energy1-percent"),
    cooldown: document.getElementById("cooldown1"),
  },
  player2: {
    health: document.getElementById("health2"),
    energy: document.getElementById("energy2"),
    healthPercent: document.getElementById("health2-percent"),
    energyPercent: document.getElementById("energy2-percent"),
    cooldown: document.getElementById("cooldown2"),
  },
};

////////////////////////////////////////////////////////////////////////////////
// Funciones de utilidades
////////////////////////////////////////////////////////////////////////////////

function preloadCharacterImages(type) {
  const prefix = type.charAt(0).toUpperCase() + type.slice(1);
  const basePath = "Fotos/";
  const images = {
    normal: `${prefix}Normal.jpeg`,
    attack: `${prefix}Ataque.jpeg`,
    special: `${prefix}Regenerar.jpeg`,
  };

  Object.entries(images).forEach(([action, src]) => {
    const imgObj = new Image();
    imgObj.onerror = () => console.error(`Error cargando: ${basePath}${src}`);
    imgObj.onload = () => console.log(`Imagen cargada: ${basePath}${src}`);
    imgObj.src = `${basePath}${src}`;
  });
}

function handleEscape() {
  if (keys.Space && game.isRunning) {
      if (confirm("¿Estás seguro de que quieres salir? Esta partida no se guardará en el historial.")) {
          partidaAbandonada = true;
          game.isRunning = false;
          setTimeout(() => {
              window.location.href = "PáginaPrincipal.html";
          }, 100);
      }
  }
}


////////////////////////////////////////////////////////////////////////////////
// Funciones de inicio y cuenta regresiva
////////////////////////////////////////////////////////////////////////////////

function startCountdown() {
  let count = 3;
  const countdownInterval = setInterval(() => {
    if (count > 0) {
      updateCountdownText(count);
    } else if (count === 0) {
      updateCountdownText("!START!");
      gameStartTimestamp = performance.now();
    }
    count--;
    if (count < 0) {
      clearInterval(countdownInterval);
      game.isRunning = true;
      game.lastFrame = performance.now();
      gameLoop(game.lastFrame);
      clearCountdownText();
    }
  }, 1000);
}

function updateCountdownText(text) {
  if (countdownDisplay) {
    countdownDisplay.textContent = text;
  } else {
    // Si no hay un elemento countdown, se usa actionsDisplay temporalmente
    actionsDisplay.textContent = text;
  }
}

function clearCountdownText() {
  if (countdownDisplay) {
    countdownDisplay.textContent = "";
  } else {
    actionsDisplay.textContent = "";
  }
}

////////////////////////////////////////////////////////////////////////////////
// Configuración de personajes e inputs
////////////////////////////////////////////////////////////////////////////////

function setupCharacter(player) {
  switch (player.type) {
    case "mago":
      player.attackDamage = 15;
      player.specialDamage = 25;
      player.energyCost = 30;
      player.normalEnergyCost = 10;
      break;
    case "guerrero":
      player.attackDamage = 20;
      player.specialDamage = 30;
      player.energyCost = 40;
      player.normalEnergyCost = 15;
      break;
    case "vampiro":
      player.attackDamage = 15;
      player.specialDamage = 20;
      player.energyCost = 35;
      player.normalEnergyCost = 12;
      break;
    default:
      location.reload();
  }
  preloadCharacterImages(player.type);
}

function handleInput(event) {
  if (!game.isRunning) return;

  keys[event.code] = (event.type === "keydown");
  if (event.code === "Space") handleEscape();

  // Prevenir comportamiento por defecto de las teclas asignadas
  if (["KeyA", "KeyS", "KeyD", "KeyK", "KeyL", "KeyJ"].includes(event.code)) {
    event.preventDefault();
  }
  console.log(`Tecla: ${event.code}, Estado: ${event.type}`);
}

////////////////////////////////////////////////////////////////////////////////
// Funciones de juego: ataque, esquivar y ataque especial
////////////////////////////////////////////////////////////////////////////////

// Modificar las funciones de ataque para contar estadísticas
function attack(player, target) {
  if (player.cooldown <= 0 && player.energy >= player.normalEnergyCost && player.canAttack) {
      player.energy -= player.normalEnergyCost;
      player.cooldown = CONFIG.ATTACK_COOLDOWN;

      if (!target.isInvisible) {
          target.health = Math.max(target.health - player.attackDamage, 0);
          // Registrar daño infligido
          player.damageDealt = (player.damageDealt || 0) + player.attackDamage;
          logAction(`${player.name} ataca (${player.attackDamage} daño)`);
          document.getElementById(target === players.player1 ? "player1" : "player2").classList.add("damaged");
      } else {
          logAction(`${target.name} esquiva el ataque!`);
          document.getElementById(target === players.player1 ? "player1" : "player2").classList.add("dodge-effect");
          setTimeout(() => {
              document.getElementById(target === players.player1 ? "player1" : "player2").classList.remove("dodge-effect");
          }, 500);
      }
      updateCharacterImage(player, "attack");
  }
}

function specialAttack(player, target) {
  if (player.specialCooldown <= 0 && player.energy >= player.energyCost) {
      player.energy -= player.energyCost;
      player.specialCooldown = CONFIG.SPECIAL_COOLDOWN;
      // Registrar uso de especial
      player.specialsUsed = (player.specialsUsed || 0) + 1;

      if (!target.isInvisible) {
          switch (player.type) {
              case "mago":
                  player.health = Math.min(player.health + 10, CONFIG.MAX_HEALTH);
                  break;
              case "vampiro":
                  target.health = Math.max(target.health - player.specialDamage, 0);
                  player.health = Math.min(player.health + player.specialDamage, CONFIG.MAX_HEALTH);
                  // Registrar daño de vampiro
                  player.damageDealt = (player.damageDealt || 0) + player.specialDamage;
                  break;
              default:
                  target.health = Math.max(target.health - player.specialDamage, 0);
                  player.damageDealt = (player.damageDealt || 0) + player.specialDamage;
          }
      }
      updateCharacterImage(player, "special");
      logAction(`${player.name} usa especial!`);
  }
}


function handleDodge(player) {
  if (player.dodgeCooldown <= 0 && player.energy >= 30) {
      player.energy -= 30;
      player.isInvisible = true;
      player.canAttack = false;
      player.dodgeCooldown = CONFIG.DODGE_COOLDOWN;
      // Registrar esquiva
      player.dodgesUsed = (player.dodgesUsed || 0) + 1;

      const element = document.getElementById(player === players.player1 ? "player1" : "player2");
      element.style.opacity = "0.5";
      element.style.border = "3px dashed #00FFFF";

      setTimeout(() => {
          player.isInvisible = false;
          player.canAttack = true;
          element.style.opacity = "1";
          element.style.border = "4px solid #FFD700";
      }, CONFIG.DODGE_COOLDOWN);
      logAction(`${player.name} esquiva!`);
  }
}

////////////////////////////////////////////////////////////////////////////////
// Actualización del HUD, imágenes de personajes y comprobación del fin
////////////////////////////////////////////////////////////////////////////////

function updateHUD() {
  ["player1", "player2"].forEach((p) => {
    const player = players[p];
    // Calcular el porcentaje de vida restante basado en CONFIG.MAX_HEALTH
    const healthPercentage = (player.health / CONFIG.MAX_HEALTH) * 100;
    
    // Actualizar la barra de salud
    if (HUD[p].health) {
      HUD[p].health.style.width = `${healthPercentage}%`;
    }
    
    if (HUD[p].healthPercent) {
      HUD[p].healthPercent.textContent = `${Math.round(healthPercentage)}%`;
    }
    
    // Actualizar la barra de energía de manera similar
    const energyPercentage = (player.energy / CONFIG.MAX_ENERGY) * 100;
    if (HUD[p].energy) {
      HUD[p].energy.style.width = `${energyPercentage}%`;
    }
    if (HUD[p].energyPercent) {
      HUD[p].energyPercent.textContent = `${Math.round(energyPercentage)}%`;
    }
    
    // Actualizar información de cooldowns
    const cooldownText = `Ataque: ${Math.ceil(player.cooldown / 1000)}s | Especial: ${Math.ceil(player.specialCooldown / 1000)}s | Esquivar: ${Math.ceil(player.dodgeCooldown / 1000)}s`;
    if (HUD[p].cooldown) {
      HUD[p].cooldown.textContent = cooldownText;
    }
  });
}

function updateCharacterImage(player, action) {
  const element = document.getElementById(player === players.player1 ? "player1" : "player2");
  const type = player.type.charAt(0).toUpperCase() + player.type.slice(1);
  let imageName = "";
  if (action === "attack") {
    imageName = `${type}Ataque.jpeg`;
  } else if (action === "special") {
    imageName = `${type}Regenerar.jpeg`;
  } else {
    imageName = `${type}Normal.jpeg`;
  }
  element.style.backgroundImage = `url('Fotos/${imageName}')`;

  if (action === "attack") {
    // Añadir efecto de ataque
    element.classList.add("attack-effect");

    // Eliminar la clase luego de 500ms (cuando termina la animación)
    setTimeout(() => {
      element.classList.remove("attack-effect");
      updateCharacterImage(player, "normal");
    }, 500);
  }
}

//función checkGameOver
function checkGameOver() {
  if (players.player1.health <= 0 || players.player2.health <= 0) {
      game.isRunning = false;
      
      if (partidaAbandonada) return true;

    // Calcular duración en segundos directamente
    const duracionSegundos = Math.floor((performance.now() - gameStartTimestamp) / 1000);
    
    // Asegurarnos de que es un número válido (entre 1 y 180 segundos - 3 minutos)
    const duracionFinal = Math.max(1, Math.min(duracionSegundos, 180)) * 1000;
      
      let winner;     
      if (players.player1.health <= 0 && players.player2.health <= 0) {
          winner = null; // Empate
          setTimeout(() => {
              alert("¡Es un empate!");
              guardarPartida(winner, duracionFinal);
              window.location.href = "PáginaPrincipal.html";
          }, 100);
      } else if (players.player1.health <= 0) {
          winner = "player2";
          setTimeout(() => {
              alert(`${players.player2.name} ha ganado!`);
              guardarPartida(winner, duracionFinal);
              window.location.href = "PáginaPrincipal.html";
          }, 100);
      } else {
          winner = "player1";
          setTimeout(() => {
              alert(`${players.player1.name} ha ganado!`);
              guardarPartida(winner, duracionFinal);
              window.location.href = "PáginaPrincipal.html";
          }, 100);
      }
      return true;
  }
  return false;
}

////////////////////////////////////////////////////////////////////////////////
// Loop principal del juego
////////////////////////////////////////////////////////////////////////////////

function gameLoop(timestamp) {
  if (!game.isRunning) return;

  // Validar que game.startTime sea correcto
  if (!game.startTime || isNaN(game.startTime)) {
    console.error('Timestamp de inicio inválido, reiniciando');
    game.startTime = timestamp;
  }
  
  const elapsed = timestamp - game.startTime;
  if (elapsed >= 180000) { // límite de 3 minutos
    game.isRunning = false;
    alert("¡Tiempo agotado!");
    window.location.href = "PáginaPrincipal.html";
    return;
  }
  
  // Actualizar el temporizador del HUD
  const minutes = Math.floor(elapsed / 60000);
  const seconds = Math.floor((elapsed % 60000) / 1000);
  timerDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, "0")}`;
  
  const deltaTime = timestamp - game.lastFrame;
  [players.player1, players.player2].forEach((p) => {
    p.cooldown = Math.max(p.cooldown - deltaTime, 0);
    p.specialCooldown = Math.max(p.specialCooldown - deltaTime, 0);
    p.dodgeCooldown = Math.max(p.dodgeCooldown - deltaTime, 0);
    p.energy = Math.min(p.energy + CONFIG.ENERGY_REGEN_RATE * deltaTime, CONFIG.MAX_ENERGY);
  });
  
  // Procesar entradas de los jugadores
  if (keys.KeyA) attack(players.player1, players.player2);
  if (keys.KeyS) handleDodge(players.player1);
  if (keys.KeyD) specialAttack(players.player1, players.player2);
  
  if (keys.KeyK) attack(players.player2, players.player1);
  if (keys.KeyL) handleDodge(players.player2);
  if (keys.KeyJ) specialAttack(players.player2, players.player1);
  
  updateHUD();
  game.lastFrame = timestamp;
  
  // Verificar si ha finalizado la partida
  if (!checkGameOver()) {
    requestAnimationFrame(gameLoop);
  }
}

////////////////////////////////////////////////////////////////////////////////
// Inicialización del juego y registro de acciones
////////////////////////////////////////////////////////////////////////////////

function initGame() {
  // Reinicializar propiedades de los jugadores
  Object.keys(players).forEach((p) => {
      players[p] = {
          ...players[p],
          health: CONFIG.MAX_HEALTH,
          energy: CONFIG.MAX_ENERGY,
          cooldown: 0,
          specialCooldown: 0,
          dodgeCooldown: 0,
          isInvisible: false,
          canAttack: true,
          attackDamage: 0,
          specialDamage: 0,
          energyCost: 0,
          normalEnergyCost: 0,
          damageDealt: 0,
          specialsUsed: 0,
          dodgesUsed: 0
      };
  });
  
  // Pedir nombre y tipo de personaje a cada jugador
  const nombre1 = prompt("Nombre del Jugador 1:");
  players.player1.name = nombre1 || "Jugador 1";
  
  const type1 = prompt(`${players.player1.name} - Elige tipo (Mago/Guerrero/Vampiro):`);
  players.player1.type = (type1 && ["mago", "guerrero", "vampiro"].includes(type1.toLowerCase()))
      ? type1.toLowerCase()
      : "guerrero";
  
  const nombre2 = prompt("Nombre del Jugador 2:");
  players.player2.name = nombre2 || "Jugador 2";
  
  const type2 = prompt(`${players.player2.name} - Elige tipo (Mago/Guerrero/Vampiro):`);
  players.player2.type = (type2 && ["mago", "guerrero", "vampiro"].includes(type2.toLowerCase()))
      ? type2.toLowerCase()
      : "guerrero";
  
  setupCharacter(players.player1);
  setupCharacter(players.player2);
  updateCharacterImage(players.player1, "normal");
  updateCharacterImage(players.player2, "normal");

  gameStartTimestamp = performance.now();
  
  // Iniciar la cuenta regresiva para el comienzo del juego
  startCountdown();
}

function logAction(action) {
  console.log(action);
  const logEntry = document.createElement("p");
  logEntry.textContent = action;
  actionsDisplay.appendChild(logEntry);
}
